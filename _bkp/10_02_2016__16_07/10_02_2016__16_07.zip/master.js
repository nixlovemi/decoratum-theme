function clearCart(){
	var url = document.location.href;
	var idx = url.indexOf('?');
	
	if(idx > 0){
		var url_split = url.split('?');
		url = url_split[0];
	}
	
	url = url + '?a=clearCart';
	document.location.href = url;
}

function removeCartItem(id_prod){
	if( confirm('Deseja retirar esse item do carrinho?') ){
		var htmlForm = '<form action="" method="POST" id="frmDeletaItemCarrinho">';
		htmlForm    += "  <input type='hidden' name='ID_PROD_DEL' value='"+id_prod+"' />";
		htmlForm    += '</form>';
		
		$('body').append(htmlForm);
		setTimeout(" $('form#frmDeletaItemCarrinho').submit(); ", 500);
	}
}

function updateCart(){
	// pega todas as selects com a qtdes
	var arr_valores = new Array();
	
	$( ".qtd-item-carrinho" ).each(function( index ) {
		var id_prod = $(this).attr('data-id-prod');
		var qtde = $(this).val();
		
		var array = new Array();
		array["id_prod"] = id_prod;
		array["qtde"] = qtde;
		
		arr_valores.push( $.extend({}, array) );
	});
	
	var JSONResp = {"produtos" : $.extend({}, arr_valores)};
	var StringJSONResp = JSON.stringify(JSONResp);
	
	var htmlForm = '<form action="" method="POST" id="frmAtualizaCarrinho">';
	htmlForm    += "  <input type='hidden' name='stringfyJSON' value='"+encodeURIComponent(StringJSONResp)+"' />";
	htmlForm    += '</form>';
	
	$('body').append(htmlForm);
	setTimeout(" $('form#frmAtualizaCarrinho').submit(); ", 500);
}